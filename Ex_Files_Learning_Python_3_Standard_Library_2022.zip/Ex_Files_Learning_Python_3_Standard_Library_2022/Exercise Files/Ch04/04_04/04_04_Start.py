# Create a Timer with the Time module
