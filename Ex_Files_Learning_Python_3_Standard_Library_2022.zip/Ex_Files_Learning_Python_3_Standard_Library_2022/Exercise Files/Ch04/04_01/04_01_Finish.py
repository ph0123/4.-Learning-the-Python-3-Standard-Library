# Datetime Module Part I
from datetime import datetime

now = datetime.now()

print(now.date())

print(now.year)

print(now.month)

print(now.hour)

print(now.minute)

print(now.second)

print(now.time())