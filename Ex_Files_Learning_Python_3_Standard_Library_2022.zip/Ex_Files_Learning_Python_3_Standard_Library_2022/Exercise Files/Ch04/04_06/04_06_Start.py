# Text Wrap Module

websiteText = """   Learning can happen anywhere with our apps on your computer,
mobile device, and TV, featuring enhanced navigation and faster streaming
for anytime learning. Limitless learning, limitless possibilities."""

print("No Dedent:")

print("Dedent")

print("Fill")

print("Controlling Indent")

print("Shortening Text")