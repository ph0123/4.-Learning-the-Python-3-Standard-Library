# Calendar Module
from datetime import datetime

now = datetime.now()