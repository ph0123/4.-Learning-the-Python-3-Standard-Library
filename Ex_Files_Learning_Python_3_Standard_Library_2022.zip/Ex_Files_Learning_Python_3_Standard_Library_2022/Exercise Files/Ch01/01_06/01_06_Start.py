# Python Rounding, Absolute Value, and Exponents

# round()

# abs()

# pow()