# Files and File Writing

# Open a file

# w --> write
# r --> read
# r+ --> read and write
# a --> append
# Show attributes and properties of that file

# Write to a file

# Read the file