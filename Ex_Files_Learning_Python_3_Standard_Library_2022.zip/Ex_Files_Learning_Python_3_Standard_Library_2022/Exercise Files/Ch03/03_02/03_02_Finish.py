# Output
print("Hello.")

# Input
color = input("What is your favorite color?")
print(color)