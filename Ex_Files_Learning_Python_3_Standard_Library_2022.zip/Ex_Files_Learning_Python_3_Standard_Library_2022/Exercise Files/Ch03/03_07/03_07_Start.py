# Zipfile Module

# Open and List

# Metadata in the zip folder

# Access to files in zip folder

# Extracting files

# Closing the zip

