# Command Line Arguments

# Print Arguments

# Remove Arguments

# Sum up the Arguments